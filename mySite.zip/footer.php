<!-- Footer
============================================= -->
<footer id="footer" class="dark noborder">

	<!-- Copyrights
	============================================= -->
	<div id="copyrights">
		<div class="container center clearfix">
			&copy; Olaoluwani Onafowope 2018 | All Rights Reserved
		</div>
	</div>
	<!-- #copyrights end -->

</footer><!-- #footer end -->